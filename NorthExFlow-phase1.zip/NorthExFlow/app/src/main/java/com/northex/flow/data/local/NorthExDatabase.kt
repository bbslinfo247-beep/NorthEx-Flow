package com.northex.flow.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.northex.flow.data.local.dao.CategoryDao
import com.northex.flow.data.local.dao.NoteDao
import com.northex.flow.data.local.dao.NoteImageDao
import com.northex.flow.data.local.dao.TaskDao
import com.northex.flow.data.local.entity.CategoryEntity
import com.northex.flow.data.local.entity.NoteEntity
import com.northex.flow.data.local.entity.NoteImageEntity
import com.northex.flow.data.local.entity.TaskItemEntity

/**
 * Schema version 1.
 *
 * When you change any entity: bump [version], add a Migration and register it with
 * addMigrations(...) in [create]. Never use fallbackToDestructiveMigration, it deletes user notes.
 * Reminders (a later phase) will be the first change: new reminder and due date columns on notes.
 */
@Database(
    entities = [
        NoteEntity::class,
        CategoryEntity::class,
        TaskItemEntity::class,
        NoteImageEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class NorthExDatabase : RoomDatabase() {

    abstract fun noteDao(): NoteDao
    abstract fun categoryDao(): CategoryDao
    abstract fun taskDao(): TaskDao
    abstract fun noteImageDao(): NoteImageDao

    companion object {
        const val NAME = "northex_flow.db"

        fun create(context: Context): NorthExDatabase =
            Room.databaseBuilder(
                context.applicationContext,
                NorthExDatabase::class.java,
                NAME
            )
                .addCallback(SeedCallback)
                .build()
    }
}

/** Runs once, when the database file is first created. Inserts the four default categories. */
private object SeedCallback : RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
        val now = System.currentTimeMillis()
        val defaults = listOf(
            Triple("Work", "কাজ", 0),
            Triple("Personal", "ব্যক্তিগত", 1),
            Triple("Study", "পড়াশোনা", 2),
            Triple("Ideas", "ধারণা", 3)
        )
        defaults.forEach { (name, nameBn, order) ->
            db.execSQL(
                "INSERT INTO categories (name, nameBn, isDefault, sortOrder, createdAt) VALUES (?, ?, 1, ?, ?)",
                arrayOf<Any>(name, nameBn, order, now)
            )
        }
    }
}
