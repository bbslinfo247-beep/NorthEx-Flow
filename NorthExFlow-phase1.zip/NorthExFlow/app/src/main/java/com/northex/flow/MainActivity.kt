package com.northex.flow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.northex.flow.ui.home.HomeViewModel

/**
 * Phase 1 placeholder. It only proves that Room, the repository and the ViewModel are wired together:
 * it lists the seeded categories and the note count. Phase 2 replaces this with the real UI.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as NorthExApp).container
        setContent {
            MaterialTheme {
                val viewModel: HomeViewModel = viewModel(factory = HomeViewModel.factory(container))
                val state by viewModel.uiState.collectAsStateWithLifecycle()
                Surface(modifier = Modifier.fillMaxSize()) {
                    Column(modifier = Modifier.safeDrawingPadding().padding(24.dp)) {
                        Text("NorthEx Flow", style = MaterialTheme.typography.headlineMedium)
                        Text(
                            "Database ready. Notes: ${state.notes.size}",
                            modifier = Modifier.padding(top = 12.dp)
                        )
                        Text(
                            "Categories: " + state.categories.joinToString { "${it.name} / ${it.nameBn}" },
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }
        }
    }
}
