package com.northex.flow.data

import kotlinx.coroutines.flow.Flow

class NoteRepository(private val dao: NoteDao) {
    fun notes(): Flow<List<NoteEntity>> = dao.observeActive()
    fun search(query: String): Flow<List<NoteEntity>> = dao.search(query)
    suspend fun save(note: NoteEntity) = dao.upsert(note)
    suspend fun delete(note: NoteEntity) = dao.delete(note)
}

class TaskRepository(private val dao: TaskDao) {
    fun tasks(): Flow<List<TaskEntity>> = dao.observeAll()
    suspend fun save(task: TaskEntity) = dao.upsert(task)
    suspend fun delete(task: TaskEntity) = dao.delete(task)
}
