package com.northex.flow.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val body: String = "",
    val category: String = "Personal",
    val color: Int = 0xFFFFF4CC.toInt(),
    val pinned: Boolean = false,
    val archived: Boolean = false,
    val imageUris: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val completed: Boolean = false,
    val dueAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
