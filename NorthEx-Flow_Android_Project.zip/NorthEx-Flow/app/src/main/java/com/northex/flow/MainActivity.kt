package com.northex.flow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewModelScope
import com.northex.flow.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        val factory = FlowViewModel.Factory(NoteRepository(db.noteDao()), TaskRepository(db.taskDao()))
        setContent { MaterialTheme { NorthExScreen(factory) } }
    }
}

class FlowViewModel(private val notesRepo: NoteRepository, private val tasksRepo: TaskRepository) : ViewModel() {
    val notes = notesRepo.notes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val tasks = tasksRepo.tasks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun addNote(title: String, body: String) = viewModelScope.launch { notesRepo.save(NoteEntity(title = title, body = body)) }
    fun toggleTask(task: TaskEntity) = viewModelScope.launch { tasksRepo.save(task.copy(completed = !task.completed)) }
    fun addTask(title: String) = viewModelScope.launch { tasksRepo.save(TaskEntity(title = title)) }
    class Factory(private val notes: NoteRepository, private val tasks: TaskRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = FlowViewModel(notes, tasks) as T
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NorthExScreen(factory: ViewModelProvider.Factory) {
    val vm: FlowViewModel = viewModel(factory = factory)
    val notes by vm.notes.collectAsState()
    val tasks by vm.tasks.collectAsState()
    var query by remember { mutableStateOf("") }
    var showNote by remember { mutableStateOf(false) }
    var showTask by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var taskTitle by remember { mutableStateOf("") }
    Scaffold(
        topBar = { TopAppBar(title = { Text("NorthEx Flow") }) },
        floatingActionButton = { FloatingActionButton(onClick = { showNote = true }) { Icon(Icons.Default.Add, contentDescription = "Add note") } }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search notes / নোট খুঁজুন") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true) }
            item { Text("Your notes / তোমার নোট", style = MaterialTheme.typography.titleMedium) }
            items(notes.filter { query.isBlank() || it.title.contains(query, true) || it.body.contains(query, true) }) { note ->
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(note.color)), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(note.title.ifBlank { "Untitled note" }, style = MaterialTheme.typography.titleMedium)
                        if (note.body.isNotBlank()) Text(note.body, style = MaterialTheme.typography.bodyMedium)
                        Text(note.category, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Tasks / কাজ", style = MaterialTheme.typography.titleMedium); TextButton(onClick = { showTask = true }) { Text("Add task") } } }
            items(tasks) { task ->
                Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { Checkbox(checked = task.completed, onCheckedChange = { vm.toggleTask(task) }); Text(task.title, modifier = Modifier.padding(top = 12.dp)) } }
            }
        }
    }
    if (showNote) AlertDialog(onDismissRequest = { showNote = false }, title = { Text("New note / নতুন নোট") }, text = { Column { OutlinedTextField(title, { title = it }, label = { Text("Title / শিরোনাম") }); OutlinedTextField(body, { body = it }, label = { Text("Write something / লিখুন") }) } }, confirmButton = { TextButton(onClick = { vm.addNote(title, body); title = ""; body = ""; showNote = false }) { Text("Save") } }, dismissButton = { TextButton(onClick = { showNote = false }) { Text("Cancel") } })
    if (showTask) AlertDialog(onDismissRequest = { showTask = false }, title = { Text("New task / নতুন কাজ") }, text = { OutlinedTextField(taskTitle, { taskTitle = it }, label = { Text("Task name") }) }, confirmButton = { TextButton(onClick = { if (taskTitle.isNotBlank()) vm.addTask(taskTitle); taskTitle = ""; showTask = false }) { Text("Save") } }, dismissButton = { TextButton(onClick = { showTask = false }) { Text("Cancel") } })
}
