# NorthEx Flow

Native Android productivity app built with Kotlin, Jetpack Compose, Material 3 and Room.

## Current starter features
- Bilingual Bangla/English labels
- Local Room database for notes and tasks
- Add and search notes
- Add tasks and toggle completion
- GitHub Actions workflow to build a debug APK

## Build APK in GitHub Actions
1. Upload the contents of this project to the root of your GitHub repository (keep the `.github/workflows/build-apk.yml` path).
2. Open the repository's **Actions** tab.
3. Select **Build NorthEx Flow APK** and press **Run workflow** (or push a source change to `main`).
4. When the run succeeds, open the run and download the `NorthEx-Flow-debug-apk` artifact.
5. Extract the artifact ZIP and install `app-debug.apk` on your Android phone.

This is an early starter build, not the complete requested feature set. Grid/list, image attachments, archive/pin, custom categories, persistent theme/view preferences, reminders and backup/restore remain planned phases.
