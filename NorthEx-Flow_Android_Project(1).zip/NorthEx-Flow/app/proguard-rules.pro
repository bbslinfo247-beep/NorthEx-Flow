# Minification is off for now. Add keep rules here if you enable isMinifyEnabled later.
