package com.northex.flow.data.repository

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.northex.flow.data.local.NorthExDatabase
import com.northex.flow.domain.model.NoteDraft
import com.northex.flow.domain.model.NoteFilter
import com.northex.flow.domain.model.TaskDraft
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class NoteRepositoryTest {

    private lateinit var db: NorthExDatabase
    private lateinit var repository: NoteRepositoryImpl

    @Before
    fun setUp() {
        db = Room.inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext(),
            NorthExDatabase::class.java
        ).allowMainThreadQueries().build()
        repository = NoteRepositoryImpl(db)
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun savedChecklistComesBackOrderedWithProgress() {
        runBlocking {
            val id = repository.saveNote(
                NoteDraft(
                    title = "Groceries",
                    isChecklist = true,
                    tasks = listOf(TaskDraft("Milk"), TaskDraft("Eggs", isDone = true), TaskDraft("Rice"))
                )
            )
            val note = repository.getNote(id)
            assertNotNull(note)
            assertEquals(listOf("Milk", "Eggs", "Rice"), note!!.tasks.map { it.text })
            assertEquals(1, note.completedTaskCount)
            assertEquals(3, note.totalTaskCount)

            repository.setTaskDone(note.tasks.first().id, true)
            assertEquals(2, repository.getNote(id)!!.completedTaskCount)
        }
    }

    @Test
    fun archivingUnpinsAndMovesNoteToArchive() {
        runBlocking {
            val id = repository.saveNote(NoteDraft(title = "Pinned", isPinned = true))
            repository.setArchived(id, true)

            assertTrue(repository.observeNotes(NoteFilter()).first().isEmpty())
            val archived = repository.observeNotes(NoteFilter(archived = true)).first()
            assertEquals(1, archived.size)
            assertFalse(archived.first().note.isPinned)

            repository.setArchived(id, false)
            assertEquals(1, repository.observeNotes(NoteFilter()).first().size)
        }
    }

    @Test
    fun searchMatchesTitleBodyAndChecklistText() {
        runBlocking {
            repository.saveNote(NoteDraft(title = "Meeting plan", content = "budget review"))
            repository.saveNote(
                NoteDraft(title = "Shopping", isChecklist = true, tasks = listOf(TaskDraft("Tomatoes")))
            )
            assertEquals(1, repository.observeNotes(NoteFilter(query = "MEETING")).first().size)
            assertEquals(1, repository.observeNotes(NoteFilter(query = "budget")).first().size)
            assertEquals(1, repository.observeNotes(NoteFilter(query = "tomato")).first().size)
            assertEquals(0, repository.observeNotes(NoteFilter(query = "zzz")).first().size)
            assertEquals(2, repository.observeNotes(NoteFilter()).first().size)
        }
    }

    @Test
    fun deletingNoteAlsoDeletesItsTasks() {
        runBlocking {
            val id = repository.saveNote(
                NoteDraft(title = "Temp", isChecklist = true, tasks = listOf(TaskDraft("One")))
            )
            repository.deleteNote(id)
            assertNull(repository.getNote(id))
        }
    }

    @Test
    fun duplicateOrBlankCategoryIsRejected() {
        runBlocking {
            assertTrue(repository.addCategory("Clients", "ক্লায়েন্ট").isSuccess)
            assertTrue(repository.addCategory("clients").isFailure)
            assertTrue(repository.addCategory("   ").isFailure)
        }
    }
}
