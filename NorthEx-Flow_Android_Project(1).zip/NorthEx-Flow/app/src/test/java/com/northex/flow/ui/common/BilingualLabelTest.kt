package com.northex.flow.ui.common

import com.northex.flow.data.local.entity.CategoryEntity
import org.junit.Assert.assertEquals
import org.junit.Test

class BilingualLabelTest {

    private fun category(name: String, nameBn: String?, isDefault: Boolean) =
        CategoryEntity(name = name, nameBn = nameBn, isDefault = isDefault, createdAt = 0L)

    @Test
    fun defaultCategoriesShowFixedBanglaNames() {
        assertEquals("কাজ / Work", category("Work", "কাজ", true).bilingualLabel())
        assertEquals("ব্যক্তিগত / Personal", category("Personal", "ব্যক্তিগত", true).bilingualLabel())
        assertEquals("পড়াশোনা / Study", category("Study", "পড়াশোনা", true).bilingualLabel())
    }

    @Test
    fun ideasUsesNewBanglaNameEvenForOldDatabases() {
        // Phase 1 seeded "ধারণা". The label must still read "আইডিয়া / Ideas".
        assertEquals("আইডিয়া / Ideas", category("Ideas", "ধারণা", true).bilingualLabel())
    }

    @Test
    fun customCategoryUsesTypedBanglaNameOrEnglishOnly() {
        assertEquals("ক্লায়েন্ট / Clients", category("Clients", "ক্লায়েন্ট", false).bilingualLabel())
        assertEquals("Clients", category("Clients", null, false).bilingualLabel())
        assertEquals("Clients", category("Clients", "  ", false).bilingualLabel())
    }
}
