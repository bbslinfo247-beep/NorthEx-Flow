package com.northex.flow.data.repository

import com.northex.flow.data.local.entity.CategoryEntity
import com.northex.flow.data.local.entity.NoteWithDetails
import com.northex.flow.domain.model.NoteDraft
import com.northex.flow.domain.model.NoteFilter
import kotlinx.coroutines.flow.Flow

interface NoteRepository {

    fun observeNotes(filter: NoteFilter): Flow<List<NoteWithDetails>>

    fun observeNote(id: Long): Flow<NoteWithDetails?>

    suspend fun getNote(id: Long): NoteWithDetails?

    fun observeCategories(): Flow<List<CategoryEntity>>

    /** Inserts or updates the note, its tasks and its images in one transaction. Returns the note id. */
    suspend fun saveNote(draft: NoteDraft): Long

    suspend fun setPinned(id: Long, pinned: Boolean)

    suspend fun setArchived(id: Long, archived: Boolean)

    suspend fun deleteNote(id: Long)

    suspend fun setTaskDone(taskId: Long, done: Boolean)

    /** Fails with IllegalArgumentException when the name is blank or already used. */
    suspend fun addCategory(name: String, nameBn: String? = null): Result<Long>

    /** Default categories are never deleted. Notes in a deleted category become uncategorized. */
    suspend fun deleteCategory(id: Long)
}
