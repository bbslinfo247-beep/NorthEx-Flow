package com.northex.flow.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.northex.flow.data.local.entity.NoteEntity
import com.northex.flow.data.local.entity.NoteWithDetails
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {

    /**
     * Notes for the home screen. Pinned notes first, then newest edit first.
     * An empty [query] matches everything. Search covers title, body and checklist item text.
     * [categoryId] = null means all categories.
     */
    @Transaction
    @Query(
        """
        SELECT * FROM notes
        WHERE isArchived = :archived
          AND (:categoryId IS NULL OR categoryId = :categoryId)
          AND (
                :query = ''
                OR instr(lower(title), lower(:query)) > 0
                OR instr(lower(content), lower(:query)) > 0
                OR id IN (
                    SELECT noteId FROM task_items
                    WHERE instr(lower(text), lower(:query)) > 0
                )
          )
        ORDER BY isPinned DESC, updatedAt DESC
        """
    )
    fun observeNotes(archived: Boolean, categoryId: Long?, query: String): Flow<List<NoteWithDetails>>

    @Transaction
    @Query("SELECT * FROM notes WHERE id = :id")
    fun observeNote(id: Long): Flow<NoteWithDetails?>

    @Transaction
    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun getNote(id: Long): NoteWithDetails?

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun getEntityById(id: Long): NoteEntity?

    @Insert
    suspend fun insert(note: NoteEntity): Long

    @Update
    suspend fun update(note: NoteEntity)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE notes SET isPinned = :pinned, updatedAt = :now WHERE id = :id")
    suspend fun setPinned(id: Long, pinned: Boolean, now: Long)

    /** Archiving also unpins, like Google Keep. Restoring leaves the pin state alone. */
    @Query(
        """
        UPDATE notes
        SET isArchived = :archived,
            isPinned = CASE WHEN :archived THEN 0 ELSE isPinned END,
            updatedAt = :now
        WHERE id = :id
        """
    )
    suspend fun setArchived(id: Long, archived: Boolean, now: Long)
}
