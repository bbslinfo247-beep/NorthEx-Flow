package com.northex.flow.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "categories",
    indices = [Index(value = ["name"], unique = true)]
)
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** English name. Always filled. */
    val name: String,
    /** Optional Bangla name. Default categories have one. */
    val nameBn: String? = null,
    val isDefault: Boolean = false,
    val sortOrder: Int = 0,
    val createdAt: Long
) {
    fun displayName(preferBangla: Boolean): String =
        if (preferBangla && !nameBn.isNullOrBlank()) nameBn else name
}
