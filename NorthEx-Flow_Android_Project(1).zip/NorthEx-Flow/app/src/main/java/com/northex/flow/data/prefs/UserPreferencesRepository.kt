package com.northex.flow.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

enum class ViewMode { GRID, LIST }

enum class ThemeMode { SYSTEM, LIGHT, DARK }

internal val Context.userPrefsDataStore: DataStore<Preferences> by preferencesDataStore(name = "user_prefs")

class UserPreferencesRepository(private val dataStore: DataStore<Preferences>) {

    private val safeData: Flow<Preferences> = dataStore.data.catch { e ->
        if (e is IOException) emit(emptyPreferences()) else throw e
    }

    val viewMode: Flow<ViewMode> = safeData.map { prefs ->
        prefs[KEY_VIEW_MODE].toEnumOrDefault(ViewMode.GRID)
    }

    val themeMode: Flow<ThemeMode> = safeData.map { prefs ->
        prefs[KEY_THEME_MODE].toEnumOrDefault(ThemeMode.SYSTEM)
    }

    suspend fun setViewMode(mode: ViewMode) {
        dataStore.edit { it[KEY_VIEW_MODE] = mode.name }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        dataStore.edit { it[KEY_THEME_MODE] = mode.name }
    }

    private inline fun <reified E : Enum<E>> String?.toEnumOrDefault(default: E): E =
        this?.let { name -> enumValues<E>().firstOrNull { it.name == name } } ?: default

    private companion object {
        val KEY_VIEW_MODE = stringPreferencesKey("view_mode")
        val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
    }
}
