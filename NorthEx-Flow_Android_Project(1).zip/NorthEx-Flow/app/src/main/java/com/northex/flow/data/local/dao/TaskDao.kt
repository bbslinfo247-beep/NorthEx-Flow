package com.northex.flow.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.northex.flow.data.local.entity.TaskItemEntity

@Dao
interface TaskDao {

    @Insert
    suspend fun insertAll(tasks: List<TaskItemEntity>)

    @Query("DELETE FROM task_items WHERE noteId = :noteId")
    suspend fun deleteForNote(noteId: Long)

    @Query("UPDATE task_items SET isDone = :done WHERE id = :taskId")
    suspend fun setDone(taskId: Long, done: Boolean)
}
