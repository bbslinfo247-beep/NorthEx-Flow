package com.northex.flow.util

import kotlin.coroutines.cancellation.CancellationException

/**
 * Like runCatching, but never swallows coroutine cancellation.
 */
suspend inline fun <T> runSuspendCatching(block: () -> T): Result<T> =
    try {
        Result.success(block())
    } catch (e: CancellationException) {
        throw e
    } catch (e: Throwable) {
        Result.failure(e)
    }
