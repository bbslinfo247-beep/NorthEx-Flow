package com.northex.flow

import android.app.Application
import com.northex.flow.di.AppContainer

class NorthExApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
