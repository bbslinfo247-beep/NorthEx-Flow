package com.northex.flow.data.local.entity

import androidx.room.Embedded
import androidx.room.Relation

data class NoteWithDetails(
    @Embedded val note: NoteEntity,
    @Relation(parentColumn = "id", entityColumn = "noteId")
    val tasks: List<TaskItemEntity>,
    @Relation(parentColumn = "id", entityColumn = "noteId")
    val images: List<NoteImageEntity>,
    @Relation(parentColumn = "categoryId", entityColumn = "id")
    val category: CategoryEntity?
) {
    val totalTaskCount: Int get() = tasks.size
    val completedTaskCount: Int get() = tasks.count { it.isDone }

    /** 0f..1f. Zero when the note has no tasks. */
    val taskProgress: Float
        get() = if (tasks.isEmpty()) 0f else completedTaskCount.toFloat() / tasks.size

    /** Room does not guarantee relation order, so sort by the stored position. */
    fun sorted(): NoteWithDetails = copy(
        tasks = tasks.sortedBy { it.position },
        images = images.sortedBy { it.position }
    )
}
