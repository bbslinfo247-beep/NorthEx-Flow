package com.northex.flow.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.northex.flow.data.local.entity.CategoryEntity
import com.northex.flow.data.local.entity.NoteWithDetails
import com.northex.flow.data.prefs.UserPreferencesRepository
import com.northex.flow.data.prefs.ViewMode
import com.northex.flow.data.repository.NoteRepository
import com.northex.flow.di.AppContainer
import com.northex.flow.domain.model.NoteDraft
import com.northex.flow.domain.model.NoteFilter
import com.northex.flow.domain.model.toDraft
import com.northex.flow.util.runSuspendCatching
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUiState(
    val isLoading: Boolean = true,
    val loadFailed: Boolean = false,
    val notes: List<NoteWithDetails> = emptyList(),
    val categories: List<CategoryEntity> = emptyList(),
    val viewMode: ViewMode = ViewMode.GRID,
    val query: String = "",
    val selectedCategoryId: Long? = null,
    val showArchived: Boolean = false
) {
    /** Pinned section is only shown on the main list, never in the archive. */
    val pinnedNotes: List<NoteWithDetails>
        get() = if (showArchived) emptyList() else notes.filter { it.note.isPinned }

    val otherNotes: List<NoteWithDetails>
        get() = if (showArchived) notes else notes.filterNot { it.note.isPinned }

    val isEmpty: Boolean get() = !isLoading && !loadFailed && notes.isEmpty()
    val isSearching: Boolean get() = query.isNotBlank()
}

/** One-off messages for the UI (snackbars). The UI maps them to Bangla/English string resources. */
sealed interface HomeEvent {
    data object NoteDeleted : HomeEvent
    data class NoteArchived(val noteId: Long) : HomeEvent
    data object CategoryRejected : HomeEvent
    data object ActionFailed : HomeEvent
}

private data class NotesLoad(
    val notes: List<NoteWithDetails> = emptyList(),
    val failed: Boolean = false
)

private data class HomeControls(
    val query: String,
    val categoryId: Long?,
    val showArchived: Boolean
)

class HomeViewModel(
    private val repository: NoteRepository,
    private val preferences: UserPreferencesRepository
) : ViewModel() {

    private val searchQuery = MutableStateFlow("")
    private val selectedCategoryId = MutableStateFlow<Long?>(null)
    private val showArchived = MutableStateFlow(false)

    private val eventChannel = Channel<HomeEvent>(Channel.BUFFERED)
    val events: Flow<HomeEvent> = eventChannel.receiveAsFlow()

    private var lastDeleted: NoteDraft? = null

    @OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
    private val notesLoad: Flow<NotesLoad> = combine(
        searchQuery.debounce(200L),
        selectedCategoryId,
        showArchived
    ) { query, categoryId, archived ->
        NoteFilter(query = query.trim(), categoryId = categoryId, archived = archived)
    }
        .distinctUntilChanged()
        .flatMapLatest { filter ->
            repository.observeNotes(filter)
                .map { NotesLoad(notes = it) }
                .catch { emit(NotesLoad(failed = true)) }
        }

    private val controls: Flow<HomeControls> = combine(
        searchQuery, selectedCategoryId, showArchived
    ) { query, categoryId, archived -> HomeControls(query, categoryId, archived) }

    private val categories: Flow<List<CategoryEntity>> =
        repository.observeCategories().catch { emit(emptyList()) }

    val uiState: StateFlow<HomeUiState> = combine(
        notesLoad, categories, preferences.viewMode, controls
    ) { load, cats, mode, ctl ->
        HomeUiState(
            isLoading = false,
            loadFailed = load.failed,
            notes = load.notes,
            categories = cats,
            viewMode = mode,
            query = ctl.query,
            selectedCategoryId = ctl.categoryId,
            showArchived = ctl.showArchived
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = HomeUiState()
    )

    fun onSearchQueryChange(query: String) {
        searchQuery.value = query
    }

    fun onCategorySelected(categoryId: Long?) {
        selectedCategoryId.value = categoryId
    }

    fun onShowArchivedChange(show: Boolean) {
        showArchived.value = show
    }

    fun toggleViewMode() {
        val next = if (uiState.value.viewMode == ViewMode.GRID) ViewMode.LIST else ViewMode.GRID
        launchAction { preferences.setViewMode(next) }
    }

    fun togglePin(note: NoteWithDetails) = launchAction {
        repository.setPinned(note.note.id, !note.note.isPinned)
    }

    fun archive(noteId: Long) = launchAction {
        repository.setArchived(noteId, true)
        eventChannel.send(HomeEvent.NoteArchived(noteId))
    }

    fun restore(noteId: Long) = launchAction {
        repository.setArchived(noteId, false)
    }

    fun delete(note: NoteWithDetails) = launchAction {
        lastDeleted = note.toDraft()
        repository.deleteNote(note.note.id)
        eventChannel.send(HomeEvent.NoteDeleted)
    }

    /** Brings back the most recently deleted note. It gets a new id and a fresh edit time. */
    fun undoDelete() = launchAction {
        val draft = lastDeleted ?: return@launchAction
        repository.saveNote(draft.copy(id = NoteDraft.NEW_ID))
        lastDeleted = null
    }

    fun setTaskDone(taskId: Long, done: Boolean) = launchAction {
        repository.setTaskDone(taskId, done)
    }

    fun addCategory(name: String, nameBn: String? = null) {
        viewModelScope.launch {
            repository.addCategory(name, nameBn)
                .onFailure { eventChannel.send(HomeEvent.CategoryRejected) }
        }
    }

    fun deleteCategory(categoryId: Long) = launchAction {
        if (selectedCategoryId.value == categoryId) selectedCategoryId.value = null
        repository.deleteCategory(categoryId)
    }

    private fun launchAction(block: suspend () -> Unit) {
        viewModelScope.launch {
            runSuspendCatching { block() }
                .onFailure { eventChannel.send(HomeEvent.ActionFailed) }
        }
    }

    companion object {
        fun factory(container: AppContainer) = viewModelFactory {
            initializer {
                HomeViewModel(container.noteRepository, container.preferencesRepository)
            }
        }
    }
}
