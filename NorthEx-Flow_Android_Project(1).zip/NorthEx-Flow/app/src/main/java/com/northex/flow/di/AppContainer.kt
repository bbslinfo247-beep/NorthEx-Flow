package com.northex.flow.di

import android.content.Context
import com.northex.flow.data.local.NorthExDatabase
import com.northex.flow.data.prefs.UserPreferencesRepository
import com.northex.flow.data.prefs.userPrefsDataStore
import com.northex.flow.data.repository.NoteRepository
import com.northex.flow.data.repository.NoteRepositoryImpl

/** Hand-written dependency container. Small enough that Hilt is not worth the build cost yet. */
class AppContainer(context: Context) {

    private val appContext = context.applicationContext

    private val database: NorthExDatabase by lazy { NorthExDatabase.create(appContext) }

    val noteRepository: NoteRepository by lazy { NoteRepositoryImpl(database) }

    val preferencesRepository: UserPreferencesRepository by lazy {
        UserPreferencesRepository(appContext.userPrefsDataStore)
    }
}
