package com.northex.flow.ui.common

import com.northex.flow.data.local.entity.CategoryEntity

/** Fixed Bangla names for the default categories, keyed by their English name. */
private val DefaultCategoryBangla = mapOf(
    "work" to "কাজ",
    "personal" to "ব্যক্তিগত",
    "study" to "পড়াশোনা",
    "ideas" to "আইডিয়া"
)

/**
 * "বাংলা / English" label for a category.
 * Default categories use the fixed names above, so databases created by Phase 1 (which stored a different
 * Bangla word for Ideas) show the same label as new installs. Custom categories use the Bangla name
 * the user typed, or just the English name when there is none.
 */
fun CategoryEntity.bilingualLabel(): String {
    val bangla = if (isDefault) {
        DefaultCategoryBangla[name.trim().lowercase()] ?: nameBn
    } else {
        nameBn
    }
    return if (bangla.isNullOrBlank()) name else "$bangla / $name"
}
