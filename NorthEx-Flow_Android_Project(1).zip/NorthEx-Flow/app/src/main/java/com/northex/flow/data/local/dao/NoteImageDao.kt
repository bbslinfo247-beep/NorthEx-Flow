package com.northex.flow.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.northex.flow.data.local.entity.NoteImageEntity

@Dao
interface NoteImageDao {

    @Insert
    suspend fun insertAll(images: List<NoteImageEntity>)

    @Query("DELETE FROM note_images WHERE noteId = :noteId")
    suspend fun deleteForNote(noteId: Long)
}
