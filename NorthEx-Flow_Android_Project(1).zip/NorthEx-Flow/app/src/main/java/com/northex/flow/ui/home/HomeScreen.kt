package com.northex.flow.ui.home

import androidx.activity.compose.BackHandler
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.northex.flow.R
import com.northex.flow.data.local.entity.NoteWithDetails
import com.northex.flow.data.prefs.ViewMode
import com.northex.flow.ui.common.CategoryChipRow
import com.northex.flow.ui.common.EmptyState
import kotlinx.coroutines.launch

private sealed interface HomeRow {
    data class Header(val key: String, @StringRes val title: Int) : HomeRow
    data class Item(val note: NoteWithDetails) : HomeRow
}

private fun buildRows(pinned: List<NoteWithDetails>, others: List<NoteWithDetails>): List<HomeRow> {
    val rows = mutableListOf<HomeRow>()
    if (pinned.isNotEmpty()) {
        rows += HomeRow.Header("header_pinned", R.string.section_pinned)
        pinned.forEach { rows += HomeRow.Item(it) }
        if (others.isNotEmpty()) rows += HomeRow.Header("header_others", R.string.section_others)
    }
    others.forEach { rows += HomeRow.Item(it) }
    return rows
}

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onOpenNote: (Long) -> Unit,
    onNewNote: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val deletedMessage = stringResource(R.string.msg_note_deleted)
    val archivedMessage = stringResource(R.string.msg_note_archived)
    val failedMessage = stringResource(R.string.msg_action_failed)
    val rejectedMessage = stringResource(R.string.msg_category_rejected)
    val undoLabel = stringResource(R.string.action_undo)

    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            when (event) {
                HomeEvent.NoteDeleted -> {
                    val result = snackbarHostState.showSnackbar(
                        message = deletedMessage,
                        actionLabel = undoLabel,
                        duration = SnackbarDuration.Long
                    )
                    if (result == SnackbarResult.ActionPerformed) viewModel.undoDelete()
                }
                is HomeEvent.NoteArchived -> {
                    val result = snackbarHostState.showSnackbar(
                        message = archivedMessage,
                        actionLabel = undoLabel,
                        duration = SnackbarDuration.Long
                    )
                    if (result == SnackbarResult.ActionPerformed) viewModel.restore(event.noteId)
                }
                HomeEvent.CategoryRejected -> snackbarHostState.showSnackbar(rejectedMessage)
                HomeEvent.ActionFailed -> snackbarHostState.showSnackbar(failedMessage)
            }
        }
    }

    // Registered in this order so that an open drawer closes first, then the archive view.
    BackHandler(enabled = state.showArchived) { viewModel.onShowArchivedChange(false) }
    BackHandler(enabled = drawerState.isOpen) { scope.launch { drawerState.close() } }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            HomeDrawerContent(
                showArchived = state.showArchived,
                onNotes = {
                    viewModel.onShowArchivedChange(false)
                    scope.launch { drawerState.close() }
                },
                onArchive = {
                    viewModel.onShowArchivedChange(true)
                    scope.launch { drawerState.close() }
                },
                onSettings = {
                    scope.launch { drawerState.close() }
                    onOpenSettings()
                }
            )
        }
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            floatingActionButton = {
                if (!state.showArchived) {
                    FloatingActionButton(onClick = onNewNote) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = stringResource(R.string.action_new_note)
                        )
                    }
                }
            }
        ) { padding ->
            Column(modifier = Modifier.padding(padding).fillMaxSize()) {
                SearchPill(
                    query = state.query,
                    onQueryChange = viewModel::onSearchQueryChange,
                    viewMode = state.viewMode,
                    onToggleViewMode = viewModel::toggleViewMode,
                    onMenuClick = { scope.launch { drawerState.open() } }
                )
                CategoryChipRow(
                    categories = state.categories,
                    selectedId = state.selectedCategoryId,
                    noneLabel = stringResource(R.string.category_all),
                    onSelect = viewModel::onCategorySelected,
                    modifier = Modifier.fillMaxWidth()
                )
                if (state.showArchived) {
                    Text(
                        text = stringResource(R.string.archive_screen_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 20.dp, top = 12.dp, end = 16.dp)
                    )
                }

                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    when {
                        state.isLoading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))

                        state.loadFailed -> EmptyState(
                            icon = Icons.Outlined.Info,
                            title = stringResource(R.string.error_load_notes)
                        )

                        state.isEmpty -> when {
                            state.isSearching -> EmptyState(
                                icon = Icons.Outlined.Search,
                                title = stringResource(R.string.empty_search_title)
                            )
                            state.showArchived -> EmptyState(
                                icon = Icons.Outlined.Archive,
                                title = stringResource(R.string.empty_archive_title)
                            )
                            else -> EmptyState(
                                icon = Icons.Outlined.Lightbulb,
                                title = stringResource(R.string.empty_notes_title),
                                body = stringResource(R.string.empty_notes_body)
                            )
                        }

                        else -> {
                            val rows = remember(state.notes, state.showArchived) {
                                buildRows(state.pinnedNotes, state.otherNotes)
                            }
                            NotesContent(
                                rows = rows,
                                viewMode = state.viewMode,
                                isArchivedView = state.showArchived,
                                onOpenNote = onOpenNote,
                                onTogglePin = viewModel::togglePin,
                                onArchiveOrRestore = { note ->
                                    if (state.showArchived) viewModel.restore(note.note.id)
                                    else viewModel.archive(note.note.id)
                                },
                                onDelete = viewModel::delete,
                                onTaskToggle = viewModel::setTaskDone
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotesContent(
    rows: List<HomeRow>,
    viewMode: ViewMode,
    isArchivedView: Boolean,
    onOpenNote: (Long) -> Unit,
    onTogglePin: (NoteWithDetails) -> Unit,
    onArchiveOrRestore: (NoteWithDetails) -> Unit,
    onDelete: (NoteWithDetails) -> Unit,
    onTaskToggle: (Long, Boolean) -> Unit
) {
    // Bottom padding keeps the last card clear of the floating action button.
    val contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 96.dp)

    if (viewMode == ViewMode.GRID) {
        LazyVerticalStaggeredGrid(
            columns = StaggeredGridCells.Adaptive(150.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = contentPadding,
            verticalItemSpacing = 8.dp,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            rows.forEach { row ->
                when (row) {
                    is HomeRow.Header -> item(key = row.key, span = StaggeredGridItemSpan.FullLine) {
                        SectionHeader(row.title)
                    }
                    is HomeRow.Item -> item(key = "note_${row.note.note.id}") {
                        NoteCard(
                            note = row.note,
                            isArchivedView = isArchivedView,
                            maxBodyLines = 8,
                            onClick = { onOpenNote(row.note.note.id) },
                            onTogglePin = { onTogglePin(row.note) },
                            onArchiveOrRestore = { onArchiveOrRestore(row.note) },
                            onDelete = { onDelete(row.note) },
                            onTaskToggle = onTaskToggle
                        )
                    }
                }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = contentPadding,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(
                items = rows,
                key = { row ->
                    when (row) {
                        is HomeRow.Header -> row.key
                        is HomeRow.Item -> "note_${row.note.note.id}"
                    }
                }
            ) { row ->
                when (row) {
                    is HomeRow.Header -> SectionHeader(row.title)
                    is HomeRow.Item -> NoteCard(
                        note = row.note,
                        isArchivedView = isArchivedView,
                        maxBodyLines = 4,
                        onClick = { onOpenNote(row.note.note.id) },
                        onTogglePin = { onTogglePin(row.note) },
                        onArchiveOrRestore = { onArchiveOrRestore(row.note) },
                        onDelete = { onDelete(row.note) },
                        onTaskToggle = onTaskToggle
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(@StringRes title: Int) {
    Text(
        text = stringResource(title),
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 4.dp, top = 8.dp, bottom = 2.dp)
    )
}

@Composable
private fun SearchPill(
    query: String,
    onQueryChange: (String) -> Unit,
    viewMode: ViewMode,
    onToggleViewMode: () -> Unit,
    onMenuClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onMenuClick) {
                Icon(
                    imageVector = Icons.Filled.Menu,
                    contentDescription = stringResource(R.string.action_open_menu)
                )
            }
            TextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = {
                    Text(
                        text = stringResource(R.string.search_hint),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    errorContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    disabledIndicatorColor = Color.Transparent,
                    errorIndicatorColor = Color.Transparent
                )
            )
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = stringResource(R.string.action_clear_search)
                    )
                }
            }
            // Shows the layout you would switch to, and says so in its description.
            IconButton(onClick = onToggleViewMode) {
                if (viewMode == ViewMode.GRID) {
                    Icon(
                        imageVector = Icons.Filled.ViewAgenda,
                        contentDescription = stringResource(R.string.action_list_view)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.GridView,
                        contentDescription = stringResource(R.string.action_grid_view)
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeDrawerContent(
    showArchived: Boolean,
    onNotes: () -> Unit,
    onArchive: () -> Unit,
    onSettings: () -> Unit
) {
    ModalDrawerSheet {
        Column(modifier = Modifier.padding(horizontal = 28.dp, vertical = 24.dp)) {
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.titleLarge
            )
            Text(
                text = stringResource(R.string.app_tagline),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        NavigationDrawerItem(
            label = { Text(stringResource(R.string.nav_notes)) },
            icon = { Icon(Icons.Outlined.Lightbulb, contentDescription = null) },
            selected = !showArchived,
            onClick = onNotes,
            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
        )
        NavigationDrawerItem(
            label = { Text(stringResource(R.string.nav_archive)) },
            icon = { Icon(Icons.Outlined.Archive, contentDescription = null) },
            selected = showArchived,
            onClick = onArchive,
            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
        )
        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp, horizontal = 28.dp))
        NavigationDrawerItem(
            label = { Text(stringResource(R.string.nav_settings)) },
            icon = { Icon(Icons.Outlined.Settings, contentDescription = null) },
            selected = false,
            onClick = onSettings,
            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
        )
    }
}
