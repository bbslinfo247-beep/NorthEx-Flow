package com.northex.flow.domain.model

import com.northex.flow.data.local.entity.NoteWithDetails

/** Number of pastel colors in the UI palette. Stored colorIndex is always in 0 until this value. */
const val NOTE_COLOR_COUNT = 8

data class TaskDraft(
    val text: String,
    val isDone: Boolean = false
)

/** Everything the editor can change on a note. Passed to the repository to save in one transaction. */
data class NoteDraft(
    val id: Long = NEW_ID,
    val title: String = "",
    val content: String = "",
    val colorIndex: Int = 0,
    val isPinned: Boolean = false,
    val isArchived: Boolean = false,
    val isChecklist: Boolean = false,
    val categoryId: Long? = null,
    val tasks: List<TaskDraft> = emptyList(),
    val imageUris: List<String> = emptyList()
) {
    companion object {
        /** Matches Room's autoGenerate: 0 means "not saved yet". */
        const val NEW_ID = 0L
    }
}

data class NoteFilter(
    val query: String = "",
    val categoryId: Long? = null,
    val archived: Boolean = false
)

fun NoteWithDetails.toDraft(): NoteDraft = NoteDraft(
    id = note.id,
    title = note.title,
    content = note.content,
    colorIndex = note.colorIndex,
    isPinned = note.isPinned,
    isArchived = note.isArchived,
    isChecklist = note.isChecklist,
    categoryId = note.categoryId,
    tasks = tasks.sortedBy { it.position }.map { TaskDraft(it.text, it.isDone) },
    imageUris = images.sortedBy { it.position }.map { it.uri }
)
