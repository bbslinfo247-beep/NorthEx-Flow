package com.northex.flow.ui.editor

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.CheckBox
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Unarchive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconToggleButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.northex.flow.R
import com.northex.flow.ui.common.CategoryChipRow
import com.northex.flow.ui.common.EmptyState
import com.northex.flow.ui.common.NoteColorPicker
import com.northex.flow.ui.common.PlainTextField
import com.northex.flow.ui.theme.noteContainerColor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditorScreen(
    viewModel: NoteEditorViewModel,
    isNewNote: Boolean,
    onClose: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    val saveFailedMessage = stringResource(R.string.msg_save_failed)
    val loadFailedMessage = stringResource(R.string.msg_load_failed)

    var showOptions by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }

    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            when (event) {
                EditorEvent.Close -> onClose()
                EditorEvent.SaveFailed -> snackbarHostState.showSnackbar(saveFailedMessage)
                EditorEvent.LoadFailed -> snackbarHostState.showSnackbar(loadFailedMessage)
            }
        }
    }

    // Leaving the editor (back arrow or system back) saves. A note that failed to load just closes.
    val handleBack: () -> Unit = {
        if (state.notFound) onClose() else viewModel.saveAndClose()
    }
    BackHandler(onBack = handleBack)

    val titleFocus = remember { FocusRequester() }
    LaunchedEffect(isNewNote) {
        if (isNewNote) runCatching { titleFocus.requestFocus() }
    }

    // When a checklist row is added, move the cursor into it.
    val taskFocusRequesters = remember { mutableMapOf<Long, FocusRequester>() }
    var lastTaskCount by remember { mutableIntStateOf(state.tasks.size) }
    LaunchedEffect(state.tasks.size) {
        if (state.tasks.size > lastTaskCount) {
            val last = state.tasks.lastOrNull()
            if (last != null && last.text.isBlank()) {
                taskFocusRequesters[last.key]?.let { runCatching { it.requestFocus() } }
            }
        }
        lastTaskCount = state.tasks.size
    }

    val container = noteContainerColor(state.colorIndex)

    Scaffold(
        modifier = Modifier.imePadding(),
        containerColor = container,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {},
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    scrolledContainerColor = Color.Transparent
                ),
                navigationIcon = {
                    IconButton(onClick = handleBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.action_back)
                        )
                    }
                },
                actions = {
                    if (!state.isLoading && !state.notFound) {
                        IconButton(onClick = viewModel::togglePinned) {
                            Icon(
                                imageVector = if (state.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                                contentDescription = stringResource(
                                    if (state.isPinned) R.string.action_unpin else R.string.action_pin
                                )
                            )
                        }
                        IconButton(onClick = viewModel::toggleArchived) {
                            Icon(
                                imageVector = if (state.isArchived) Icons.Outlined.Unarchive else Icons.Outlined.Archive,
                                contentDescription = stringResource(
                                    if (state.isArchived) R.string.action_restore else R.string.action_archive
                                )
                            )
                        }
                        if (!isNewNote) {
                            IconButton(onClick = { showDeleteDialog = true }) {
                                Icon(
                                    imageVector = Icons.Outlined.Delete,
                                    contentDescription = stringResource(R.string.action_delete)
                                )
                            }
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (!state.isLoading && !state.notFound) {
                EditorBottomBar(
                    state = state,
                    showOptions = showOptions,
                    onShowOptionsChange = { showOptions = it },
                    categories = categories,
                    onChecklistChange = viewModel::setChecklistMode,
                    onColorChange = viewModel::onColorChange,
                    onCategoryChange = viewModel::onCategoryChange
                )
            }
        }
    ) { padding ->
        when {
            state.isLoading -> Column(
                modifier = Modifier.padding(padding).fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
            ) {
                CircularProgressIndicator()
            }

            state.notFound -> EmptyState(
                icon = Icons.Outlined.Info,
                title = stringResource(R.string.editor_not_found),
                modifier = Modifier.padding(padding)
            )

            else -> Column(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp)
            ) {
                PlainTextField(
                    value = state.title,
                    onValueChange = viewModel::onTitleChange,
                    placeholder = stringResource(R.string.editor_title_hint),
                    textStyle = MaterialTheme.typography.headlineSmall.copy(
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.fillMaxWidth().focusRequester(titleFocus),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                )

                if (state.isChecklist) {
                    if (state.totalTaskCount > 0) {
                        ChecklistProgress(
                            done = state.completedTaskCount,
                            total = state.totalTaskCount,
                            progress = state.taskProgress
                        )
                    }
                    state.tasks.forEach { task ->
                        key(task.key) {
                            TaskEditRow(
                                task = task,
                                focusRequester = taskFocusRequesters.getOrPut(task.key) { FocusRequester() },
                                onTextChange = { viewModel.onTaskTextChange(task.key, it) },
                                onCheckedChange = { viewModel.onTaskCheckedChange(task.key, it) },
                                onRemove = { viewModel.removeTask(task.key) },
                                onNext = viewModel::addTask
                            )
                        }
                    }
                    TextButton(
                        onClick = viewModel::addTask,
                        modifier = Modifier.padding(start = 8.dp)
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.editor_add_item))
                    }
                } else {
                    PlainTextField(
                        value = state.content,
                        onValueChange = viewModel::onContentChange,
                        placeholder = stringResource(R.string.editor_content_hint),
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 240.dp)
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text(stringResource(R.string.editor_delete_title)) },
            text = { Text(stringResource(R.string.editor_delete_body)) },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteDialog = false
                    viewModel.deleteAndClose()
                }) { Text(stringResource(R.string.action_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }
}

@Composable
private fun ChecklistProgress(done: Int, total: Int, progress: Float) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            text = stringResource(R.string.task_progress, done, total),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun TaskEditRow(
    task: EditorTask,
    focusRequester: FocusRequester,
    onTextChange: (String) -> Unit,
    onCheckedChange: (Boolean) -> Unit,
    onRemove: () -> Unit,
    onNext: () -> Unit
) {
    val itemHint = stringResource(R.string.editor_item_hint)
    val textStyle = MaterialTheme.typography.bodyLarge.copy(
        color = if (task.isDone) MaterialTheme.colorScheme.onSurfaceVariant
        else MaterialTheme.colorScheme.onSurface,
        textDecoration = if (task.isDone) TextDecoration.LineThrough else TextDecoration.None
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(
            checked = task.isDone,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.semantics {
                contentDescription = task.text.ifBlank { itemHint }
            }
        )
        PlainTextField(
            value = task.text,
            onValueChange = onTextChange,
            placeholder = itemHint,
            textStyle = textStyle,
            modifier = Modifier.weight(1f).focusRequester(focusRequester),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { onNext() })
        )
        IconButton(onClick = onRemove) {
            Icon(
                imageVector = Icons.Filled.Close,
                contentDescription = stringResource(R.string.action_remove_item)
            )
        }
    }
}

@Composable
private fun EditorBottomBar(
    state: EditorUiState,
    showOptions: Boolean,
    onShowOptionsChange: (Boolean) -> Unit,
    categories: List<com.northex.flow.data.local.entity.CategoryEntity>,
    onChecklistChange: (Boolean) -> Unit,
    onColorChange: (Int) -> Unit,
    onCategoryChange: (Long?) -> Unit
) {
    Surface(color = Color.Transparent) {
        Column(modifier = Modifier.navigationBarsPadding()) {
            AnimatedVisibility(visible = showOptions) {
                Column(modifier = Modifier.padding(bottom = 8.dp)) {
                    Text(
                        text = stringResource(R.string.editor_color),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 4.dp)
                    )
                    NoteColorPicker(
                        selectedIndex = state.colorIndex,
                        onSelect = onColorChange
                    )
                    Text(
                        text = stringResource(R.string.editor_category),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp)
                    )
                    CategoryChipRow(
                        categories = categories,
                        selectedId = state.categoryId,
                        noneLabel = stringResource(R.string.category_none),
                        onSelect = onCategoryChange,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconToggleButton(checked = state.isChecklist, onCheckedChange = onChecklistChange) {
                    Icon(
                        imageVector = Icons.Outlined.CheckBox,
                        contentDescription = stringResource(R.string.editor_checklist),
                        tint = if (state.isChecklist) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconToggleButton(checked = showOptions, onCheckedChange = onShowOptionsChange) {
                    Icon(
                        imageVector = Icons.Outlined.Palette,
                        contentDescription = stringResource(R.string.editor_options),
                        tint = if (showOptions) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
