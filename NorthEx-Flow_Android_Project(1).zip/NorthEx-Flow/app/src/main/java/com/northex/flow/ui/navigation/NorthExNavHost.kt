package com.northex.flow.ui.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.northex.flow.di.AppContainer
import com.northex.flow.domain.model.NoteDraft
import com.northex.flow.ui.editor.NoteEditorScreen
import com.northex.flow.ui.editor.NoteEditorViewModel
import com.northex.flow.ui.home.HomeScreen
import com.northex.flow.ui.home.HomeViewModel
import com.northex.flow.ui.settings.SettingsScreen
import com.northex.flow.ui.settings.SettingsViewModel

object Routes {
    const val HOME = "home"
    const val SETTINGS = "settings"
    const val ARG_NOTE_ID = "noteId"
    const val EDITOR = "editor/{$ARG_NOTE_ID}"

    /** Pass [NoteDraft.NEW_ID] to create a new note. */
    fun editor(noteId: Long) = "editor/$noteId"
}

@Composable
fun NorthExNavHost(
    container: AppContainer,
    navController: NavHostController = rememberNavController()
) {
    NavHost(navController = navController, startDestination = Routes.HOME) {

        composable(Routes.HOME) {
            val viewModel: HomeViewModel = viewModel(factory = HomeViewModel.factory(container))
            HomeScreen(
                viewModel = viewModel,
                onOpenNote = { noteId -> navController.navigate(Routes.editor(noteId)) },
                onNewNote = { navController.navigate(Routes.editor(NoteDraft.NEW_ID)) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }

        composable(
            route = Routes.EDITOR,
            arguments = listOf(navArgument(Routes.ARG_NOTE_ID) { type = NavType.LongType })
        ) { entry ->
            val noteId = entry.arguments?.getLong(Routes.ARG_NOTE_ID) ?: NoteDraft.NEW_ID
            val viewModel: NoteEditorViewModel = viewModel(
                factory = NoteEditorViewModel.factory(container.noteRepository, noteId)
            )
            NoteEditorScreen(
                viewModel = viewModel,
                isNewNote = noteId == NoteDraft.NEW_ID,
                onClose = { navController.popBackStack() }
            )
        }

        composable(Routes.SETTINGS) {
            val viewModel: SettingsViewModel = viewModel(factory = SettingsViewModel.factory(container))
            SettingsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
