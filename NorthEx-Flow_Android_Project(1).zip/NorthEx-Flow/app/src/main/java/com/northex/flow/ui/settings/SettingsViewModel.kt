package com.northex.flow.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.northex.flow.data.local.entity.CategoryEntity
import com.northex.flow.data.prefs.ThemeMode
import com.northex.flow.data.prefs.UserPreferencesRepository
import com.northex.flow.data.prefs.ViewMode
import com.northex.flow.data.repository.NoteRepository
import com.northex.flow.di.AppContainer
import com.northex.flow.util.runSuspendCatching
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SettingsUiState(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val viewMode: ViewMode = ViewMode.GRID,
    val categories: List<CategoryEntity> = emptyList()
)

sealed interface SettingsEvent {
    data object CategoryRejected : SettingsEvent
    data object ActionFailed : SettingsEvent
}

class SettingsViewModel(
    private val repository: NoteRepository,
    private val preferences: UserPreferencesRepository
) : ViewModel() {

    private val eventChannel = Channel<SettingsEvent>(Channel.BUFFERED)
    val events: Flow<SettingsEvent> = eventChannel.receiveAsFlow()

    val uiState: StateFlow<SettingsUiState> = combine(
        preferences.themeMode,
        preferences.viewMode,
        repository.observeCategories().catch { emit(emptyList()) }
    ) { theme, view, categories ->
        SettingsUiState(themeMode = theme, viewMode = view, categories = categories)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = SettingsUiState()
    )

    fun setThemeMode(mode: ThemeMode) = launchAction { preferences.setThemeMode(mode) }

    fun setViewMode(mode: ViewMode) = launchAction { preferences.setViewMode(mode) }

    fun addCategory(name: String, nameBn: String?) {
        viewModelScope.launch {
            repository.addCategory(name, nameBn)
                .onFailure { eventChannel.send(SettingsEvent.CategoryRejected) }
        }
    }

    fun deleteCategory(categoryId: Long) = launchAction { repository.deleteCategory(categoryId) }

    private fun launchAction(block: suspend () -> Unit) {
        viewModelScope.launch {
            runSuspendCatching { block() }
                .onFailure { eventChannel.send(SettingsEvent.ActionFailed) }
        }
    }

    companion object {
        fun factory(container: AppContainer) = viewModelFactory {
            initializer {
                SettingsViewModel(container.noteRepository, container.preferencesRepository)
            }
        }
    }
}
