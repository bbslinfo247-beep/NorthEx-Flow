package com.northex.flow.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Unarchive
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.northex.flow.R
import com.northex.flow.data.local.entity.NoteWithDetails
import com.northex.flow.data.local.entity.TaskItemEntity
import com.northex.flow.ui.common.bilingualLabel
import com.northex.flow.ui.theme.noteContainerColor

private const val MAX_PREVIEW_TASKS = 4

@Composable
fun NoteCard(
    note: NoteWithDetails,
    isArchivedView: Boolean,
    maxBodyLines: Int,
    onClick: () -> Unit,
    onTogglePin: () -> Unit,
    onArchiveOrRestore: () -> Unit,
    onDelete: () -> Unit,
    onTaskToggle: (taskId: Long, done: Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val entity = note.note
    val hasTitle = entity.title.isNotBlank()
    val hasBody = !entity.isChecklist && entity.content.isNotBlank()

    Card(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = noteContainerColor(entity.colorIndex),
            contentColor = MaterialTheme.colorScheme.onSurface
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(start = 14.dp, top = 6.dp, end = 4.dp, bottom = 12.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Box(modifier = Modifier.weight(1f).padding(top = 8.dp)) {
                    if (hasTitle) {
                        Text(
                            text = entity.title,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                if (entity.isPinned) {
                    Icon(
                        imageVector = Icons.Filled.PushPin,
                        contentDescription = stringResource(R.string.note_is_pinned),
                        modifier = Modifier.padding(top = 10.dp).size(18.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                NoteMenu(
                    isPinned = entity.isPinned,
                    isArchivedView = isArchivedView,
                    onTogglePin = onTogglePin,
                    onArchiveOrRestore = onArchiveOrRestore,
                    onDelete = onDelete
                )
            }

            Column(modifier = Modifier.padding(end = 10.dp)) {
                if (hasBody) {
                    Text(
                        text = entity.content,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = maxBodyLines,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = if (hasTitle) 4.dp else 8.dp)
                    )
                }

                if (entity.isChecklist && note.tasks.isNotEmpty()) {
                    Column(modifier = Modifier.padding(top = if (hasTitle) 4.dp else 8.dp)) {
                        note.tasks.take(MAX_PREVIEW_TASKS).forEach { task ->
                            TaskPreviewRow(
                                task = task,
                                onToggle = { done -> onTaskToggle(task.id, done) }
                            )
                        }
                        val hidden = note.tasks.size - MAX_PREVIEW_TASKS
                        if (hidden > 0) {
                            Text(
                                text = stringResource(R.string.task_more, hidden),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                            )
                        }
                        TaskProgress(done = note.completedTaskCount, total = note.totalTaskCount, progress = note.taskProgress)
                    }
                }

                val category = note.category
                val imageCount = note.images.size
                if (category != null || imageCount > 0) {
                    Row(
                        modifier = Modifier.padding(top = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (category != null) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                                contentColor = MaterialTheme.colorScheme.onSurface
                            ) {
                                Text(
                                    text = category.bilingualLabel(),
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        if (imageCount > 0) {
                            Icon(
                                imageVector = Icons.Outlined.Image,
                                contentDescription = stringResource(R.string.images_count, imageCount),
                                modifier = Modifier.size(18.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TaskPreviewRow(task: TaskItemEntity, onToggle: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 44.dp)
            .toggleable(value = task.isDone, role = Role.Checkbox, onValueChange = onToggle),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = task.isDone, onCheckedChange = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = task.text,
            style = MaterialTheme.typography.bodyMedium,
            textDecoration = if (task.isDone) TextDecoration.LineThrough else TextDecoration.None,
            color = if (task.isDone) MaterialTheme.colorScheme.onSurfaceVariant else Color.Unspecified,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun TaskProgress(done: Int, total: Int, progress: Float) {
    Column(modifier = Modifier.padding(top = 6.dp)) {
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            text = stringResource(R.string.task_progress, done, total),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

@Composable
private fun NoteMenu(
    isPinned: Boolean,
    isArchivedView: Boolean,
    onTogglePin: () -> Unit,
    onArchiveOrRestore: () -> Unit,
    onDelete: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { expanded = true }, modifier = Modifier.size(40.dp)) {
            Icon(
                imageVector = Icons.Filled.MoreVert,
                contentDescription = stringResource(R.string.action_more)
            )
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            if (!isArchivedView) {
                DropdownMenuItem(
                    text = { Text(stringResource(if (isPinned) R.string.action_unpin else R.string.action_pin)) },
                    leadingIcon = {
                        Icon(
                            imageVector = if (isPinned) Icons.Outlined.PushPin else Icons.Filled.PushPin,
                            contentDescription = null
                        )
                    },
                    onClick = {
                        expanded = false
                        onTogglePin()
                    }
                )
            }
            DropdownMenuItem(
                text = {
                    Text(stringResource(if (isArchivedView) R.string.action_restore else R.string.action_archive))
                },
                leadingIcon = {
                    Icon(
                        imageVector = if (isArchivedView) Icons.Outlined.Unarchive else Icons.Outlined.Archive,
                        contentDescription = null
                    )
                },
                onClick = {
                    expanded = false
                    onArchiveOrRestore()
                }
            )
            DropdownMenuItem(
                text = { Text(stringResource(R.string.action_delete)) },
                leadingIcon = { Icon(Icons.Outlined.Delete, contentDescription = null) },
                onClick = {
                    expanded = false
                    onDelete()
                }
            )
        }
    }
}
