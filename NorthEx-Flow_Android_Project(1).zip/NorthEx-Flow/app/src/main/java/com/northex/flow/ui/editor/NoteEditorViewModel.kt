package com.northex.flow.ui.editor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.northex.flow.data.local.entity.CategoryEntity
import com.northex.flow.data.local.entity.NoteWithDetails
import com.northex.flow.data.repository.NoteRepository
import com.northex.flow.domain.model.NOTE_COLOR_COUNT
import com.northex.flow.domain.model.NoteDraft
import com.northex.flow.domain.model.TaskDraft
import com.northex.flow.util.runSuspendCatching
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** A checklist row while editing. [key] is a stable id for LazyColumn, it is not stored in the database. */
data class EditorTask(
    val key: Long,
    val text: String,
    val isDone: Boolean = false
)

data class EditorUiState(
    val isLoading: Boolean = false,
    val notFound: Boolean = false,
    val isSaving: Boolean = false,
    val title: String = "",
    val content: String = "",
    val colorIndex: Int = 0,
    val categoryId: Long? = null,
    val isPinned: Boolean = false,
    val isArchived: Boolean = false,
    val isChecklist: Boolean = false,
    val tasks: List<EditorTask> = emptyList(),
    val imageUris: List<String> = emptyList()
) {
    private val filledTasks: List<EditorTask> get() = tasks.filter { it.text.isNotBlank() }

    val completedTaskCount: Int get() = filledTasks.count { it.isDone }
    val totalTaskCount: Int get() = filledTasks.size
    val taskProgress: Float
        get() = if (filledTasks.isEmpty()) 0f else completedTaskCount.toFloat() / filledTasks.size

    val isBlank: Boolean
        get() = title.isBlank() && content.isBlank() && filledTasks.isEmpty() && imageUris.isEmpty()
}

sealed interface EditorEvent {
    /** Saved (or nothing to save). The screen can navigate back. */
    data object Close : EditorEvent
    data object SaveFailed : EditorEvent
    data object LoadFailed : EditorEvent
}

/**
 * @param noteId [NoteDraft.NEW_ID] to create a note, or the id of an existing note to edit.
 * Draft text is held in memory only. Process death while editing loses unsaved text (acceptable for now,
 * a later phase can persist drafts).
 */
class NoteEditorViewModel(
    private val repository: NoteRepository,
    private val noteId: Long
) : ViewModel() {

    private val _uiState = MutableStateFlow(EditorUiState(isLoading = noteId != NoteDraft.NEW_ID))
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    val categories: StateFlow<List<CategoryEntity>> = repository.observeCategories()
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val eventChannel = Channel<EditorEvent>(Channel.BUFFERED)
    val events: Flow<EditorEvent> = eventChannel.receiveAsFlow()

    private var nextTaskKey = 0L

    /** Snapshot taken after loading, used to skip saving when nothing changed. */
    private var loadedDraft: NoteDraft? = null

    init {
        if (noteId != NoteDraft.NEW_ID) load()
    }

    private fun load() {
        viewModelScope.launch {
            runSuspendCatching { repository.getNote(noteId) }
                .onSuccess { note ->
                    if (note == null) {
                        _uiState.update { it.copy(isLoading = false, notFound = true) }
                    } else {
                        val state = note.toEditorState()
                        _uiState.value = state
                        loadedDraft = state.toDraft(noteId)
                    }
                }
                .onFailure {
                    _uiState.update { s -> s.copy(isLoading = false, notFound = true) }
                    eventChannel.send(EditorEvent.LoadFailed)
                }
        }
    }

    fun onTitleChange(value: String) = _uiState.update { it.copy(title = value) }

    fun onContentChange(value: String) = _uiState.update { it.copy(content = value) }

    fun onColorChange(index: Int) =
        _uiState.update { it.copy(colorIndex = index.coerceIn(0, NOTE_COLOR_COUNT - 1)) }

    fun onCategoryChange(categoryId: Long?) = _uiState.update { it.copy(categoryId = categoryId) }

    fun togglePinned() = _uiState.update { it.copy(isPinned = !it.isPinned) }

    fun toggleArchived() = _uiState.update {
        val archived = !it.isArchived
        it.copy(isArchived = archived, isPinned = if (archived) false else it.isPinned)
    }

    /**
     * Switches between a text note and a checklist.
     * Text to checklist: each non-empty line becomes a task.
     * Checklist to text: task texts become lines (done state is dropped).
     */
    fun setChecklistMode(enabled: Boolean) = _uiState.update { s ->
        when {
            enabled == s.isChecklist -> s
            enabled -> {
                val lines = s.content.lines().map { it.trim() }.filter { it.isNotEmpty() }
                val converted = lines.map { EditorTask(key = nextTaskKey++, text = it) }
                val tasks = (s.tasks + converted).ifEmpty { listOf(EditorTask(key = nextTaskKey++, text = "")) }
                s.copy(isChecklist = true, content = "", tasks = tasks)
            }
            else -> {
                val text = s.tasks.map { it.text.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
                s.copy(isChecklist = false, content = text, tasks = emptyList())
            }
        }
    }

    fun addTask() = _uiState.update {
        it.copy(tasks = it.tasks + EditorTask(key = nextTaskKey++, text = ""))
    }

    fun onTaskTextChange(key: Long, text: String) = _uiState.update { s ->
        s.copy(tasks = s.tasks.map { if (it.key == key) it.copy(text = text) else it })
    }

    fun onTaskCheckedChange(key: Long, done: Boolean) = _uiState.update { s ->
        s.copy(tasks = s.tasks.map { if (it.key == key) it.copy(isDone = done) else it })
    }

    fun removeTask(key: Long) = _uiState.update { s ->
        s.copy(tasks = s.tasks.filterNot { it.key == key })
    }

    fun addImages(uris: List<String>) = _uiState.update { s ->
        s.copy(imageUris = (s.imageUris + uris).distinct())
    }

    fun removeImage(uri: String) = _uiState.update { s ->
        s.copy(imageUris = s.imageUris.filterNot { it == uri })
    }

    /**
     * Saves and then emits [EditorEvent.Close].
     * A blank new note is discarded. A blank existing note is deleted. An unchanged note is not rewritten.
     */
    fun saveAndClose() {
        val state = _uiState.value
        if (state.isLoading || state.notFound || state.isSaving) return

        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            val draft = state.toDraft(noteId)
            runSuspendCatching {
                when {
                    state.isBlank -> if (noteId != NoteDraft.NEW_ID) repository.deleteNote(noteId)
                    draft == loadedDraft -> Unit
                    else -> repository.saveNote(draft)
                }
            }
                .onSuccess { eventChannel.send(EditorEvent.Close) }
                .onFailure {
                    _uiState.update { it.copy(isSaving = false) }
                    eventChannel.send(EditorEvent.SaveFailed)
                }
        }
    }

    /** Deletes the note being edited (nothing to delete for a new note) and emits [EditorEvent.Close]. */
    fun deleteAndClose() {
        if (_uiState.value.isSaving) return
        viewModelScope.launch {
            runSuspendCatching {
                if (noteId != NoteDraft.NEW_ID) repository.deleteNote(noteId)
            }
                .onSuccess { eventChannel.send(EditorEvent.Close) }
                .onFailure { eventChannel.send(EditorEvent.SaveFailed) }
        }
    }

    private fun NoteWithDetails.toEditorState(): EditorUiState = EditorUiState(
        isLoading = false,
        title = note.title,
        content = note.content,
        colorIndex = note.colorIndex,
        categoryId = note.categoryId,
        isPinned = note.isPinned,
        isArchived = note.isArchived,
        isChecklist = note.isChecklist,
        tasks = tasks.sortedBy { it.position }.map {
            EditorTask(key = nextTaskKey++, text = it.text, isDone = it.isDone)
        },
        imageUris = images.sortedBy { it.position }.map { it.uri }
    )

    private fun EditorUiState.toDraft(id: Long): NoteDraft = NoteDraft(
        id = id,
        title = title.trim(),
        content = content.trim(),
        colorIndex = colorIndex,
        isPinned = isPinned,
        isArchived = isArchived,
        isChecklist = isChecklist,
        categoryId = categoryId,
        tasks = if (isChecklist) {
            tasks.filter { it.text.isNotBlank() }.map { TaskDraft(it.text.trim(), it.isDone) }
        } else {
            emptyList()
        },
        imageUris = imageUris
    )

    companion object {
        fun factory(repository: NoteRepository, noteId: Long) = viewModelFactory {
            initializer { NoteEditorViewModel(repository, noteId) }
        }
    }
}
