package com.northex.flow.data.repository

import androidx.room.withTransaction
import com.northex.flow.data.local.NorthExDatabase
import com.northex.flow.data.local.entity.CategoryEntity
import com.northex.flow.data.local.entity.NoteEntity
import com.northex.flow.data.local.entity.NoteImageEntity
import com.northex.flow.data.local.entity.NoteWithDetails
import com.northex.flow.data.local.entity.TaskItemEntity
import com.northex.flow.domain.model.NOTE_COLOR_COUNT
import com.northex.flow.domain.model.NoteDraft
import com.northex.flow.domain.model.NoteFilter
import com.northex.flow.util.runSuspendCatching
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class NoteRepositoryImpl(private val db: NorthExDatabase) : NoteRepository {

    private val noteDao = db.noteDao()
    private val categoryDao = db.categoryDao()
    private val taskDao = db.taskDao()
    private val imageDao = db.noteImageDao()

    override fun observeNotes(filter: NoteFilter): Flow<List<NoteWithDetails>> =
        noteDao.observeNotes(
            archived = filter.archived,
            categoryId = filter.categoryId,
            query = filter.query.trim()
        ).map { list -> list.map { it.sorted() } }

    override fun observeNote(id: Long): Flow<NoteWithDetails?> =
        noteDao.observeNote(id).map { it?.sorted() }

    override suspend fun getNote(id: Long): NoteWithDetails? =
        noteDao.getNote(id)?.sorted()

    override fun observeCategories(): Flow<List<CategoryEntity>> =
        categoryDao.observeAll()

    override suspend fun saveNote(draft: NoteDraft): Long = db.withTransaction {
        val now = System.currentTimeMillis()
        val existing = if (draft.id != NoteDraft.NEW_ID) noteDao.getEntityById(draft.id) else null

        // Guard against a category that was deleted while the editor was open.
        val categoryId = draft.categoryId?.takeIf { categoryDao.getById(it) != null }

        val entity = NoteEntity(
            id = existing?.id ?: 0L,
            title = draft.title.trim(),
            content = if (draft.isChecklist) "" else draft.content.trim(),
            colorIndex = draft.colorIndex.coerceIn(0, NOTE_COLOR_COUNT - 1),
            isPinned = draft.isPinned,
            isArchived = draft.isArchived,
            isChecklist = draft.isChecklist,
            categoryId = categoryId,
            createdAt = existing?.createdAt ?: now,
            updatedAt = now
        )

        val noteId = if (existing == null) {
            noteDao.insert(entity)
        } else {
            noteDao.update(entity)
            existing.id
        }

        val tasks = if (draft.isChecklist) draft.tasks.filter { it.text.isNotBlank() } else emptyList()
        taskDao.deleteForNote(noteId)
        taskDao.insertAll(
            tasks.mapIndexed { index, task ->
                TaskItemEntity(
                    noteId = noteId,
                    text = task.text.trim(),
                    isDone = task.isDone,
                    position = index
                )
            }
        )

        imageDao.deleteForNote(noteId)
        imageDao.insertAll(
            draft.imageUris.distinct().mapIndexed { index, uri ->
                NoteImageEntity(noteId = noteId, uri = uri, position = index, createdAt = now)
            }
        )

        noteId
    }

    override suspend fun setPinned(id: Long, pinned: Boolean) =
        noteDao.setPinned(id, pinned, System.currentTimeMillis())

    override suspend fun setArchived(id: Long, archived: Boolean) =
        noteDao.setArchived(id, archived, System.currentTimeMillis())

    override suspend fun deleteNote(id: Long) =
        noteDao.deleteById(id)

    override suspend fun setTaskDone(taskId: Long, done: Boolean) =
        taskDao.setDone(taskId, done)

    override suspend fun addCategory(name: String, nameBn: String?): Result<Long> =
        runSuspendCatching {
            val clean = name.trim()
            require(clean.isNotEmpty()) { "Category name is empty" }
            require(categoryDao.countByName(clean) == 0) { "Category already exists" }
            categoryDao.insert(
                CategoryEntity(
                    name = clean,
                    nameBn = nameBn?.trim()?.takeIf { it.isNotEmpty() },
                    isDefault = false,
                    sortOrder = categoryDao.maxSortOrder() + 1,
                    createdAt = System.currentTimeMillis()
                )
            )
        }

    override suspend fun deleteCategory(id: Long) =
        categoryDao.deleteCustomById(id)
}
