package com.northex.flow.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.northex.flow.data.local.entity.CategoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CategoryDao {

    @Query("SELECT * FROM categories ORDER BY sortOrder ASC, id ASC")
    fun observeAll(): Flow<List<CategoryEntity>>

    @Query("SELECT * FROM categories WHERE id = :id")
    suspend fun getById(id: Long): CategoryEntity?

    @Insert
    suspend fun insert(category: CategoryEntity): Long

    /** Default categories are protected: only custom ones can be deleted. */
    @Query("DELETE FROM categories WHERE id = :id AND isDefault = 0")
    suspend fun deleteCustomById(id: Long)

    @Query("SELECT COUNT(*) FROM categories WHERE lower(name) = lower(:name)")
    suspend fun countByName(name: String): Int

    @Query("SELECT COALESCE(MAX(sortOrder), -1) FROM categories")
    suspend fun maxSortOrder(): Int
}
