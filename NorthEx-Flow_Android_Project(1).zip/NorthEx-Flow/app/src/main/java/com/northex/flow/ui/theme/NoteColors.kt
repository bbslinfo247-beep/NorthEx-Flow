package com.northex.flow.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import com.northex.flow.domain.model.NOTE_COLOR_COUNT

// Index 0 is "default" and uses the theme surface color, so it is not listed here.
private val LightNoteColors = listOf(
    Color(0xFFFFF4B0), // yellow
    Color(0xFFFFD9B8), // peach
    Color(0xFFFFC9D6), // rose
    Color(0xFFE3D1FF), // lavender
    Color(0xFFC7E4FF), // sky blue
    Color(0xFFC8F0D4), // mint
    Color(0xFFEADFCB)  // sand
)

private val DarkNoteColors = listOf(
    Color(0xFF5C5424),
    Color(0xFF6B4A2E),
    Color(0xFF6A3347),
    Color(0xFF4D3A75),
    Color(0xFF2A4F73),
    Color(0xFF2D5E43),
    Color(0xFF55493A)
)

/**
 * Background color for a note. Works with text in MaterialTheme.colorScheme.onSurface
 * in both light and dark themes.
 */
@Composable
fun noteContainerColor(colorIndex: Int): Color {
    val index = colorIndex.coerceIn(0, NOTE_COLOR_COUNT - 1)
    if (index == 0) return MaterialTheme.colorScheme.surface
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val palette = if (isDark) DarkNoteColors else LightNoteColors
    return palette[index - 1]
}
